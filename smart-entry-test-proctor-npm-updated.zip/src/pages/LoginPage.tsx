import React, { useState } from 'react';
// Removed Link and useNavigate imports as they are no longer needed for visitor link

import { Link } from 'react-router-dom';

function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('Student'); // Default role

  const handleLogin = (e) => {
    e.preventDefault();
    // Placeholder authentication logic
    console.log(`Attempting login with:
      Username: ${username}
      Password: ${password}
      Role: ${role}`);

    if (role === 'Student') {
      console.log('Authenticating as Student...');
      // Add actual student authentication logic here
    } else if (role === 'Admin' || role === 'Faculty') {
      console.log(`Authenticating as ${role} (Admin/Faculty)...`);
      // Add actual admin/faculty authentication logic here
    } else {
      console.error('Invalid role selected');
    }
    // On successful login, you might navigate elsewhere
    // Example: navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Smart Entry Test Proctor - Login</h2>
        <form onSubmit={handleLogin}>
          <div className="mb-4">
            <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">Username</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Enter your username"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Enter your password"
            />
          </div>
          <div className="mb-6">
            <label htmlFor="role" className="block text-sm font-medium text-gray-700 mb-1">Role</label>
            <select
              id="role"
              value={role}
              onChange={(e) => setRole(e.target.value)}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white"
            >
              <option value="Student">Student</option>
              <option value="Admin">Admin</option>
              <option value="Faculty">Faculty</option>
            </select>
          </div>
          <button
            type="submit"
            className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out mb-4"
          >
            Login
          </button>
          <div className="text-center">
            {/* Changed Link to span as per user request */}
            <span className="text-sm text-gray-600">
              Or continue as a visitor
            </span>
          </div>
          <div className="mt-2">
    <Link to="/forgot-password" className="text-sm text-blue-500 hover:underline">Forgot password?</Link>
  </div>
  <div className="mt-4">
    <Link to="/signup" className="text-sm text-blue-500 hover:underline">Don't have an account? Sign up</Link>
  </div>
</form>
      </div>
    </div>
  );
}

export default LoginPage;

